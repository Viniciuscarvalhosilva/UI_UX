package com.example.ui_ux;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UiUxApplicationTests {

	@Test
	void contextLoads() {
	}

}
